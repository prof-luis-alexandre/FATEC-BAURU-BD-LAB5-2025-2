import pandas as pd
import os

ARQUIVO_CSV = "dados_censo_escolar_tratados.csv"

if not os.path.exists(ARQUIVO_CSV):
    print(f"ERRO: O arquivo '{ARQUIVO_CSV}' não foi encontrado na pasta atual.")
    exit()

print(f"Lendo o arquivo: {ARQUIVO_CSV} ...")

try:
    df = pd.read_csv(ARQUIVO_CSV, encoding='utf-8')
except UnicodeDecodeError:
    df = pd.read_csv(ARQUIVO_CSV, encoding='latin-1')

print(f"Total de registros carregados: {len(df)}")

def esc(valor):
    """
    Escapa aspas simples para SQL (ex: "D'Oeste" vira "D''Oeste")
    e trata valores nulos.
    """
    if pd.isna(valor):
        return ""
    return str(valor).replace("'", "''")

def tratar_int(valor):
    """Converte float/string para int, tratando nulos como 0"""
    try:
        if pd.isna(valor): return 0
        return int(float(valor))
    except:
        return 0

print("Processando dados e gerando IDs...")

deps_unicas = df['dependencia_adm'].dropna().unique()
map_dep = {nome: i+1 for i, nome in enumerate(deps_unicas)}
df_uf = df[['codigo_uf', 'estado']].drop_duplicates()
df_mun = df[['codigo_municipio', 'municipio', 'codigo_uf']].drop_duplicates()

print("Gerando arquivos SQL...")


with open("insert_uf.sql", "w", encoding="utf-8") as f:
    f.write("-- CARGA TABELA UF\n")
    for _, row in df_uf.iterrows():
        sql = f"INSERT INTO uf (codigo_uf, nome_estado) VALUES ({row['codigo_uf']}, '{esc(row['estado'])}');\n"
        f.write(sql)


with open("insert_dependencia_adm.sql", "w", encoding="utf-8") as f:
    f.write("-- CARGA TABELA DEPENDENCIA_ADM\n")
    for nome, id_dep in map_dep.items():
        sql = f"INSERT INTO dependencia_adm (dependencia_id, nome_dependencia) VALUES ({id_dep}, '{esc(nome)}');\n"
        f.write(sql)


with open("insert_municipio.sql", "w", encoding="utf-8") as f:
    f.write("-- CARGA TABELA MUNICIPIO\n")
    for _, row in df_mun.iterrows():
        sql = f"INSERT INTO municipio (codigo_municipio, nome_municipio, codigo_uf) VALUES ({row['codigo_municipio']}, '{esc(row['municipio'])}', {row['codigo_uf']});\n"
        f.write(sql)


with open("insert_escola.sql", "w", encoding="utf-8") as f:
    f.write("-- CARGA TABELA ESCOLA\n")
    
    count = 0
    for _, row in df.iterrows():

        id_dep_fk = map_dep.get(row['dependencia_adm'], 'NULL')
        

        sql = (
            "INSERT INTO escola ("
            "ano_censo, nome_escola, codigo_municipio, dependencia_id, localizacao, "
            "possui_lab_informatica, possui_biblioteca, possui_quadra_esportes, "
            "possui_internet, possui_banda_larga, qtd_salas_utilizadas, "
            "qtd_desktops_alunos, qtd_notebooks_alunos, qtd_tablets_alunos, "
            "qtd_total_computadores_alunos"
            ") VALUES ("
            f"{tratar_int(row['ano_censo'])}, "
            f"'{esc(row['nome_escola'])}', "
            f"{tratar_int(row['codigo_municipio'])}, "
            f"{id_dep_fk}, "
            f"'{esc(row['localizacao'])}', "
            f"'{esc(row['possui_lab_informatica'])}', "
            f"'{esc(row['possui_biblioteca'])}', "
            f"'{esc(row['possui_quadra_esportes'])}', "
            f"'{esc(row['possui_internet'])}', "
            f"'{esc(row['possui_banda_larga'])}', "
            f"{tratar_int(row['qtd_salas_utilizadas'])}, "
            f"{tratar_int(row['qtd_desktops_alunos'])}, "
            f"{tratar_int(row['qtd_notebooks_alunos'])}, "
            f"{tratar_int(row['qtd_tablets_alunos'])}, "
            f"{tratar_int(row['qtd_total_computadores_alunos'])}"
            ");\n"
        )
        f.write(sql)
        count += 1

print(f"Sucesso! Foram gerados inserts para {count} escolas.")
print("Arquivos criados na pasta: insert_uf.sql, insert_dependencia_adm.sql, insert_municipio.sql, insert_escola.sql")