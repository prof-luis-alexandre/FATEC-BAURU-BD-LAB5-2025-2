-- CARGA TABELA DEPENDENCIA_ADM
INSERT INTO dependencia_adm (dependencia_id, nome_dependencia) VALUES (1, 'Estadual');
INSERT INTO dependencia_adm (dependencia_id, nome_dependencia) VALUES (2, 'Municipal');
INSERT INTO dependencia_adm (dependencia_id, nome_dependencia) VALUES (3, 'Privada');
INSERT INTO dependencia_adm (dependencia_id, nome_dependencia) VALUES (4, 'Federal');
